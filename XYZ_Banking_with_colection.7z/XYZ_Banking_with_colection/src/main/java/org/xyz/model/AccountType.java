package org.xyz.model;

public enum AccountType {
	SAVING,CURRENT,FD,RD;
}
