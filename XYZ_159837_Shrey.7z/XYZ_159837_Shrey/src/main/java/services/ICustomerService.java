package services;

import java.util.List;
import java.util.Set;

import model.Account;
import model.Customer;
import model.Transaction;

public interface ICustomerService {

	public void createCustomer(Customer customer);
	public List<Customer> getAllCustomers();
	public Customer isCustomerFound(int customerId);
        public Account isAccountFound(Customer customer,int accountNumber);
	public void AddAccount(Customer customer,Account account);
         public void addTransaction(Transaction transaction);
         public List<Transaction> getAllTransaction();
         public double getCurrentBalance(Account account,int accountNumber);
}
