package org.xyz_bank.model;

public enum AccountType {

	CURRENT,SAVINGS,FD,RD;
}
