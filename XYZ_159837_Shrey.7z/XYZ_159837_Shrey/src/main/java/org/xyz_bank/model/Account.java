package org.xyz_bank.model;

import java.time.LocalDate;

public class Account {

	private long AccountNi;
	private AccountType Acctype;
	public long getAccountNi() {
		return AccountNi;
	}
	public void setAccountNi(long accountNi) {
		AccountNi = accountNi;
	}
	public AccountType getAcctype() {
		return Acctype;
	}
	public void setAcctype(AccountType acctype) {
		Acctype = acctype;
	}
	public LocalDate getOpeningDate() {
		return OpeningDate;
	}
	public void setOpeningDate(LocalDate openingDate) {
		OpeningDate = openingDate;
	}
	public double getOpeningBalance() {
		return OpeningBalance;
	}
	public void setOpeningBalance(double openingBalance) {
		OpeningBalance = openingBalance;
	}
	public String getDescription() {
		return Description;
	}
	public void setDescription(String description) {
		Description = description;
	}
	private LocalDate OpeningDate;
	private double OpeningBalance;
	private String Description;
	
}
