package org.xyz_bank.model;

import java.time.LocalDate;

public class Transaction {

	private long transactionId;
	private LocalDate transactionDate;
	private String transactiontype;
	private double amount;
	private Account FromAccount;
	private Account ToAccount;
	
}
