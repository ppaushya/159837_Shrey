package org.xyz_bank.model;

public class Address {
	
	private String Line1;
	private String Line2;
	private String City;
	private String state;
	private int pincode;
	

}
