package org.xyz.Service;

import org.xyz_bank.model.Customer;

public class CustomerService implements ICustomerService{

	@Override
	public void getCustomerList() {
	}
	
	public List<Customer> getCustomerService(Customer addcustomer)
	{
		
	}
	

}
