package org.xyz.Service;

public interface ICustomerService {

}
