package org.xyz.view;

import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Matcher;

import org.xyz.util.Utility;
import org.xyz_bank.model.Customer;

public class UserInteraction {
	
	Scanner s=new Scanner(System.in);
	
	Utility uti= new Utility();
	
	public void getCustomerDetails()
	{
		Customer customer=new Customer();
		Utility utility=new Utility();
		int CustomerId=utility.generateRandomNumber();
		customer.setCustomerID(CustomerId);
		System.out.println("The Customer ID generated is " + CustomerId);
		System.out.println("Enter the first name");
		customer.setFirstName(promptname());
		System.out.println("Enter the Last name");
		customer.setLastName((promptname()));		
		System.out.println("Enter the Email ID");
		customer.setEmailId(promptemail());
		System.out.println("Enter the Date of Birth[DD/MM/YYYY]");
		customer.setDateOfBirth((promptdob()));		
		
		
	}
	
	public String promptname()
	{
		boolean flag=false;
		String name;
		do
		{
			
			name=s.nextLine();
			flag=uti.isValid(name);
			if(!flag)
				System.out.println("Enter Valid Name!!");
         }while(!flag);
		
		return name;
	}
	
	
	public String promptemail()
	{
		boolean flag=false;
		String name;
		do
		{
			
			name=s.nextLine();
			flag=uti.emailid(name);
			if(!flag)
				System.out.println("Enter Valid Email ID!! ");
         }while(!flag);
		
		return name;
	}
	
	public LocalDate promptdob()
	{
		String date;
		boolean flag=false;
		do
		{
			
			date=s.nextLine();
			flag=uti.dob(date);
			if(!flag)
				System.out.println("Enter Valid Date!! ");
         }while(!flag);
		String[] dateParts=date.split("/");
		return LocalDate.of(Integer.parseInt(dateParts[2]), Integer.parseInt(dateParts[1]), Integer.parseInt(dateParts[0])); 
			 
	}
	
	
	

	public static void main(String[] args) {

		
	}

}
