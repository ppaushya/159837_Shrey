package org.xyz.boot;

import org.xyz.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {

		UserInteraction userinteraction= new UserInteraction();
		userinteraction.getCustomerDetails();
	}

}
