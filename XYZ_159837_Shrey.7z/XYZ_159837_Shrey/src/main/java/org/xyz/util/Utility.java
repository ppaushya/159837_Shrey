package org.xyz.util;

import java.time.LocalDate;

public class Utility {

    public int generateRandomNumber()
    {
    	return (int)(Math.random()*1000)/255;
    }
	
    public boolean isValid(String str)
    {
    	return str.matches("[a-zA-Z]{3,}");
    }
	
    public boolean emailid(String str)
    {
    	return str.matches("[a-z][a-z0-9]+@[a-z]+.(com|in)" );
    }
    
    public boolean dob(String date)
    {
    	return date.matches("[1-3][0-9]/[0-1][1-9]/[1-2][[0-9][0-9][0-9]");
    }
	public static void main(String[] args) {

	}

}
