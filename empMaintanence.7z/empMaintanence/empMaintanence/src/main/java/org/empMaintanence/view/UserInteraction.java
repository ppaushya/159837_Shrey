
/*
package org.empMaintanence.view;

import java.time.LocalDate;
import java.util.Scanner;

import org.empMaintanence.model.Employee;
import org.empMaintanence.model.UserMaster;

public class UserInteraction {

	Scanner scanner=new Scanner(System.in);

	
	public Employee getEmployeeDetails() {
		// TODO Auto-generated method stub
		
		System.out.println("Enter the employee details");
		
		System.out.println("Enter the first name");
		
		Employee employee=new Employee();
		
		employee.setEmpFirstName(scanner.next());
		
		System.out.println("Enter the last name");
		
		employee.setEmpLastName(scanner.next());
		
		System.out.println("Enter the Date of birth[dd-mm-yyyy]");
		
		String dob=scanner.next();
		
		String date1[]=dob.split("-");
		
		employee.setEmpDateOfBirth(LocalDate.of(Integer.parseInt(date1[2]), Integer.parseInt(date1[1]), Integer.parseInt(date1[0])));
		
		employee.setEmpDateOfJoining(LocalDate.now());
		
		System.out.println("Enter the department id ");
		
		employee.setEmpDeptId(scanner.nextInt());
		
		System.out.println("Enter the employee grade ");
		
		employee.setEmpGrade(scanner.next());

		System.out.println("Enter the designation of the employee");
		
		employee.setEmpDesignation(scanner.next());
		
		System.out.println("Enter the employee basic");

		employee.setEmpBasic(scanner.nextInt());
		
		System.out.println("Enter the employee gender");
		
		employee.setEmpGender(scanner.next());
		
		System.out.println("Enter the employee marital status");
		
		employee.setEmpMaritalStatus(scanner.next());

		System.out.println("Enter the employee home address");
		
		employee.setEmpHomeAddress(scanner.next());
		
		System.out.println("Enter the employee contact no");
		
		employee.setEmpContactNo(scanner.next());
		
		
		*/

package org.empMaintanence.view;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.empMaintanence.model.*;
import org.empMaintanence.service.ILoginService;
import org.empMaintanence.service.LoginServicesImpl;
import org.empMaintanence.*;


public class UserInteraction {

	Scanner scan= new Scanner(System.in);
	

	public UserMaster getLoginDetails() {
		
		Scanner scanner= new Scanner(System.in);
		
		System.out.println("Welcome to the Employee maintanence system");
		
		
		System.out.println("Enter the login details");
		
		System.out.println("Enter the User Id");
		
		String userId=scanner.next();
		
		System.out.println("Enter the User Name");
		
		String userName=scanner.next();
		
		System.out.println("Enter the User Password");
		
		String userPw=scanner.next();
		
		System.out.println("Enter the user type");
		
		String userType=scanner.next();
		
		
		UserMaster usermaster=new UserMaster();
		
		usermaster.setUserId(userId);
		
		usermaster.setUserName(userName);
		
		usermaster.setUserPassword(userPw);
		
		usermaster.setUserType(userType);
		
		
		
		return usermaster;
	}

	
	
	public Employee addEmployeeDetails()
	{
		Employee employee = new Employee();
		
		employee.setEmpId(promptEmployeeId());
		employee.setEmpFirstName(promptFirstName());
		employee.setEmpLastName(promptLastName());
		LocalDate dateOfBirth=promptDateOfBirth();
	     employee.setEmpDateOfBirth(dateOfBirth);
	    boolean flag1=false;
	   do {
		   flag1= Utility.DobValidation(dateOfBirth);
	    if(!flag1)
	    {
	    	System.out.println("Enter a valid date of birth!!");
	    	System.out.println("Age should be between 18 and 58.");
	    	dateOfBirth=promptDateOfBirth();
	    }
	   }while(!flag1);
	   
		LocalDate dateOfJoining=promptDateOfJoining();
		 boolean flag2=false;
		   do {
			   flag2= Utility.DojValidation(dateOfJoining,dateOfBirth);
		    if(!flag2)
		    {
		    	System.out.println("Enter a valid date of joining!!");
		    	System.out.println("Date of birth should be less than date of joining.");
		    	dateOfBirth=promptDateOfBirth();
		    }
		   }while(!flag2);
		
		employee.setEmpDateOfJoining(dateOfJoining);
		
		//Department Name  
		employee.setEmpDeptId(promptDepartmentId());
		
		String grade=promptGrade();
		employee.setEmpGrade(grade);
		employee.setEmpDesignation(promptDesignation());
		employee.setEmpGender(promptGender());
		//Employee Basic
		int basic=promptEmployeeBasic(grade);
		
		boolean flag=false;
		do {
		flag=Utility.basicGradeValidation(basic,grade);
		if(!flag)
		{	System.out.println("Please enter a valid basic!! \n It does not match with the employee grade");
			System.out.println("Current grade is:"+grade);
			basic=promptEmployeeBasic(grade);
		}
		}while(!flag);
		
		employee.setEmpBasic(basic);
		employee.setEmpMaritalStatus(promptMaritalStatus());
		employee.setEmpHomeAddress(promptHomeAddress());
		employee.setEmpContactNo(promptContactNumber());
		
		return employee;
		
	}
	
	private int promptEmployeeBasic(String grade) {
		
		boolean flag=false;
		int basic=0;
		
			switch(grade)
			{
			case "M1":
				System.out.println("Enter Employee Basic[Rs.10,00,000-Rs.50,00,000]");
				basic=scan.nextInt();
				do {
					
					flag=Utility.isValidBasic(basic);
					
					if(!flag)
					{	System.out.println("Please enter a valid Employee Basic![Rs.10,00,000-Rs.50,00,000]");
						basic=scan.nextInt();
					}
					
				}while(!flag);
				break;
				
			case "M2":
				System.out.println("Enter Employee Basic[Rs.5,00,000-Rs.10,00,000]");
				basic=scan.nextInt();
				do {
					
					flag=Utility.isValidBasic(basic);
					
					if(!flag)
					{	System.out.println("Please enter a valid Employee Basic![Rs.5,00,000-Rs.10,00,000]");
						basic=scan.nextInt();
					}
					
				}while(!flag);
				break;
			
			case "M3":
				System.out.println("Enter Employee Basic[Rs.2,00,000-Rs.5,00,000]");
				basic=scan.nextInt();
				do {
					
					flag=Utility.isValidBasic(basic);
					
					if(!flag)
					{	System.out.println("Please enter a valid Employee Basic![Rs.2,00,000-Rs.5,00,000]");
						basic=scan.nextInt();
					}
					
				}while(!flag);
				break;
			
			case "M4":
				System.out.println("Enter Employee Basic[Rs.1,00,000-Rs.2,00,000]");
				basic=scan.nextInt();
				do {
					
					flag=Utility.isValidBasic(basic);
					
					if(!flag)
					{	System.out.println("Please enter a valid Employee Basic![Rs.1,00,000-Rs.2,00,000]");
						basic=scan.nextInt();
					}
					
				}while(!flag);
				break;
				
			case "M5":
				System.out.println("Enter Employee Basic[Rs.50,000-Rs.1,00,000]");
				basic=scan.nextInt();
				do {
					
					flag=Utility.isValidBasic(basic);
					
					if(!flag)
					{	System.out.println("Please enter a valid Employee Basic![Rs.50,000-Rs.1,00,000]");
						basic=scan.nextInt();
					}
					
				}while(!flag);
				break;
				
			case "M6":
				System.out.println("Enter Employee Basic[Rs.25,000-Rs.50,000]");
				basic=scan.nextInt();
				do {
					
					flag=Utility.isValidBasic(basic);
					
					if(!flag)
					{	System.out.println("Please enter a valid Employee Basic![Rs.25,000-Rs.50,000]");
						basic=scan.nextInt();
					}
					
				}while(!flag);
				break;
				
			case "M7":
				System.out.println("Enter Employee Basic[Rs.10,000-Rs.25,000]");
				basic=scan.nextInt();
				do {
					
					flag=Utility.isValidBasic(basic);
					
					if(!flag)
					{	System.out.println("Please enter a valid Employee Basic![Rs.10,000-Rs.25,000]");
						basic=scan.nextInt();
					}
					
				}while(!flag);
				break;
			}
		
		return basic;
	}
		
		
	



	private int promptDepartmentId() {
		
		ILoginService loginService= new LoginServicesImpl();
		
		List<Department> departments= new ArrayList<>();
		
		departments= loginService.displayDepartmentList();
		
		for(Department dept:departments)
		{
			System.out.println(dept.getDeptId()+".) "+dept.getDeptName());
		}
		
		int choice=0;
		System.out.println("Choose Department[1-6]");
		choice=scan.nextInt();
		do {
		switch(choice)
		{
		case 1:
			return 1;
		case 2: 
			return 2;
		case 3: 
			return 3;
		case 4: 
			return 4;
		case 5: 
			return 5;
		case 6: 
			return 6;
		default:
			System.out.println("Please enter a valid choice [1-6]");
			choice=scan.nextInt();
		
		}
		}while(true);
		
		
		
	}

	private String promptContactNumber() {
		boolean flag=false;
		String contactNo;
		
			System.out.println("Enter Contact no");
			contactNo=scan.next();
			flag=Utility.isValidContactNumber(contactNo);
			if(flag)
				return contactNo;
			return contactNo;
	}

	private String promptHomeAddress() {
		boolean flag=false;
		String address;
		
			System.out.println("Enter Home Address");
			address=scan.next();
			flag=Utility.isValidHomeAddress(address);
			if(flag)
				return address;
			return address;
				
	
	}

	private String promptMaritalStatus() {
		int choice=0;
		System.out.println("Enter the Marital Status[1-5]:\n1. Single\n2. Married\n3."
				+ "Divorced\n4. Separated\n5. Widowed");
		choice=scan.nextInt();
		do {
		switch(choice)
		{
		case 1:
			return "S";
		case 2:
			return "M";
		case 3:
			return "D";
		case 4:
			return "X";
		case 5:
			return "W";
		default:
			System.out.println("Enter valid choice for marital status!!");
			choice=scan.nextInt();
		}
			
		}while(true);
	}

	private String promptGender() {
		int choice=0;
		System.out.println("Enter the Gender[1/2]:\n1. Male\n2. Female");
		choice=scan.nextInt();
		do {
		switch(choice)
		{
		case 1:
			return "M";
		case 2:
			return "F";
		default:
			System.out.println("Enter valid choice for gender!!");
			choice=scan.nextInt();
		}
			
		}while(true);
		
	}

	private String promptDesignation() {
		boolean flag=false;
		String design;
		do {
			System.out.println("Enter Designation");
			design=scan.next();
			flag=Utility.isValidDesignation(design);
			if(!flag)
				System.out.println("Enter a valid Designation");
	
		}while(!flag);
		
		return design;
	}

	private String promptGrade() {
		
		System.out.println("Choose from below[1-7]:\n1. M1\n2. M2\n3. M3\n4. M4\n5. "
				+ "M5\n6. M6\n7. M7");
		int choice = scan.nextInt();
		do {
		switch(choice)
		{
		case 1:
			return "M1";
			
		case 2:
			return "M2";
			
		case 3:
			return "M3";
			
		case 4:
			return "M4";
			
		case 5:
			return "M5";
			
		case 6:
			return "M6";
			
		case 7:
			return "M7";
			
		default: 
			System.out.println("Invalid choice!! Please enter a valid choice.");
			choice = scan.nextInt();

		} 
		}while(true);
	}

	

	

	private String promptLastName() {
		boolean flag=true;
		String lname;
		do {
			System.out.println("Enter last name");
			 lname=scan.next();
			//flag=Utility.isValidLastName(lname);
			if(!flag)
				System.out.println("Enter a valid last name");
	
		}while(!flag);
		
		return lname;
	}

	private String promptFirstName() {
		
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter first name");
			 fname=scan.next();
			flag=Utility.isValidFirstName(fname);
			if(!flag)
				System.out.println("Enter a valid first name");
	
		}while(!flag);
		
		return fname;
	}

	private String promptEmployeeId() {
		
		boolean flag=false;
		String empId;
		do {
			System.out.println("Enter Employee ID");
			empId=scan.next();
			flag=Utility.isValidEmpId(empId);
			if(!flag)
				System.out.println("Enter a valid Employee ID");
	
		}while(!flag);
		
		return empId;
	}
   
	
private LocalDate promptDateOfBirth() {

	
	
	boolean flag=false;
	
	String dob;
	
	
		System.out.println("Enter the date of birth[dd-mmm-yyyy]");
		
		dob=scan.next();
		
		   DateTimeFormatter formatter_1=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        
		   LocalDate localDate_1= LocalDate.parse(dob,formatter_1);

		   
		   System.out.println(localDate_1);
		   
	  	return localDate_1;
	
	
	
	}

private LocalDate promptDateOfJoining() {

	
	boolean flag=false;
	
	String dob;
	
	
		System.out.println("Enter the date of joining[dd-mmm-yyyy]");
		
		dob=scan.next();
		
		   DateTimeFormatter formatter_1=DateTimeFormatter.ofPattern("dd-MMM-yyyy");
        
		   LocalDate localDate_1= LocalDate.parse(dob,formatter_1);

		   
		   System.out.println(localDate_1);
		   
	  	return localDate_1;
	
	
	
	}



public password getSecureDetails() {
	// TODO Auto-generated method stub
	
	password pass=new password();
	
	System.out.println("what's your nick name ?");
	
	Scanner scanner=new Scanner(System.in);
	
	pass.setNickName(scanner.next());
	
	System.out.println("what's ur school name ?");
	
	pass.setSchool(scanner.next());
	
	
	System.out.println("Whats's ur father's profession");
	
	pass.setFatherProfession(scanner.next());
	
	System.out.println("what's ur prime hobby");
	
	pass.setHobby(scanner.next());
	
	return pass;
}



}

		