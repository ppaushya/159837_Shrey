import java.util.Arrays;
import java.util.Scanner;

public class Customer {

	private long customerID;
	private String customerName;
	private String mobileNo;
	private String emailID;
	private Address address;
	private Account[] account=new Account[4];
	public long getCustomerID() {
		return customerID;
	}
	public void setCustomerID(long customerID) {
		this.customerID = customerID;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Account[] getAccount() {
		return account;
	}
	public void setAccount(Account[] account) {
		this.account = account;
	}
	@Override
	public String toString() {
		return "Customer ID: " + customerID + "\nCustomer Name: " + customerName + "\nMobile No: " + mobileNo
				+ "\nEmail ID: " + emailID + "\n" + address + "\n" + Arrays.toString(account);
	}
	public Customer() {
		super();
	}
	public Customer(int customerID, String customerName, String mobileNo, String emailID, Address address,
			Account[] account) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.mobileNo = mobileNo;
		this.emailID = emailID;
		this.address = address;
		this.account = account;
	}
}