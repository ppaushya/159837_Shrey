import java.time.LocalDate;
import java.util.Date;

public class Transactions {

	private int transactionID;
	private String transactionType;
	private LocalDate transactionDate;
	private Double amount;
	private Account account;
	@Override
	public String toString() {
		return "Transactions [transactionID=" + transactionID + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", amount=" + amount + ", account=" + account + "]";
	}
	public Transactions(int transactionID, String transactionType, LocalDate transactionDate, Double amount,
			Account account) {
		super();
		this.transactionID = transactionID;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.amount = amount;
		this.account = account;
	}
	public Transactions() {
		super();
	}
	public int getTransactionID() {
		return transactionID;
	}
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public LocalDate getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(LocalDate transactionDate) {
		this.transactionDate = transactionDate;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Account getAccount() {
		return account;
	}
	public void setAccount(Account account) {
		this.account = account;
	}	
}
