import java.time.LocalDate;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Main {
	
	static int index=0;
	static Customer[] customers=new Customer[5];
	static Scanner scanner=new Scanner(System.in);
	
	public static Customer[] loadCustomer() {
		
		for(int i=0;i<5;i++)
		{
			int j=i+1,k=0;
			String cID,cName,mobNo,eID;
			boolean flag;
			
			Address address=new Address("North Avennue", "Cross St", "Chennai", "TN");
			customers[i]=new Customer();
			customers[i].setAddress(address);
			
			do
			{
				System.out.println("Enter Customer ID of Customer No. " + j);
				cID=scanner.next();
				
				Pattern pattern=Pattern.compile("\\d{6,10}");
				Matcher matcher=pattern.matcher(cID);
				flag = matcher.matches();
				if(flag == false)
				{
					System.out.println("Enter correct Customer ID: ");
				}
				else
				{
					customers[i].setCustomerID(Long.parseLong(cID));
					k=1;
				}
			}while(k==0);
			
			k=0;
			do
			{
				System.out.println("Enter Full Name of Customer No. " + j);
				cName=scanner.next();
				
				Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]*");
				Matcher matcher=pattern.matcher(cName);
				flag = matcher.matches();
				if(flag == false)
				{
					System.out.println("Enter correct Name of Customer in required Format: ");
				}
				else
				{
					customers[i].setCustomerName(cName);
					k=1;
				}
			}while(k==0);
			k=0;
			do
			{
				System.out.println("Enter Mobile number of Customer No. " + j);
				mobNo=scanner.next();
				
				Pattern pattern=Pattern.compile("\\d{10}");
				Matcher matcher=pattern.matcher(mobNo);
				flag = matcher.matches();
				if(flag == false)
				{
					System.out.println("Enter correct Mobile Number of Customer: ");
				}
				else
				{
					customers[i].setMobileNo(mobNo);
					k=1;
				}
			}while(k==0);
			k=0;
			do
			{
				System.out.println("Enter Email ID of Customer No. " + j);
				eID=scanner.next();
				
				Pattern pattern=Pattern.compile("[a-z]+@gmail.com");
				Matcher matcher=pattern.matcher(eID);
				flag = matcher.matches();
				if(flag == false)
				{
					System.out.println("Enter correct Email ID of Customer in required Format: ");
				}
				else
				{
					customers[i].setEmailID(eID);
					k=1;
				}
			}while(k==0);
			k=0;
		}
		return customers;
	}
	
	public static void printCustomer() {
		System.out.println("Available Customers:");
		//Customer[] customers=loadCustomer();
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerID()+"\t"+customer.getCustomerName() +"\t"
					+customer.getEmailID()+"\t"+ customer.getMobileNo());
		}
	}
	
	public static void printAccountType() {
		AccountType[] types=AccountType.values();
		int count=0;
		for(AccountType type:types)
			System.out.println(++count + "." + type);
	}

	public static AccountType assignAccountType(int value) {
		switch(value) {
		case 1:
			return AccountType.SAVINGS;
		case 2:
			return AccountType.CURRENT;
		case 3:
			return AccountType.RD;
		case 4:
			return AccountType.FD;
		default:
			System.out.println("Invalid Account Type");
			System.exit(0);
		}
		return null;
	}
	
	public static Customer findCustomer(int customerId) {
//		for(Customer customer:loadCustomer()) {
		for(Customer customer:customers) {
			if(customer.getCustomerID()==customerId)
				return customer;
		}
		return null;
	}
	
	
	//-------------------------Main Method-----------------------------------------//
	public static void main(String[] args) {
		Transactions[] transactions=new Transactions[100];
		int choice;
		int customerID;
		int accountTypeNo;
		
		loadCustomer();
		printCustomer();
		
		char myChoice;
	do {
		System.out.println("Choose customer Id:");
		customerID=scanner.nextInt();
		Customer customer=findCustomer(customerID);
		
			if(customer!=null) {
				System.out.println("1.Create new Account");
				System.out.println("2.Perform Transaction");
				System.out.println("3.Transaction Summary");
				System.out.println("Enter your Choice[1,2,3]?");
				choice=scanner.nextInt();
				if(choice==1) {
					Account account=new Account();
					System.out.println("Enter Account details");
					
					int k=0;
					do
					{
						String accNo;
						boolean flag;
						System.out.println("Enter Account Number for New Account: ");
						accNo=scanner.next();
						
						Pattern pattern=Pattern.compile("\\d{3,6}");
						Matcher matcher=pattern.matcher(accNo);
						flag = matcher.matches();
						if(flag == false)
						{
							System.out.println("Enter correct Account Number of Customer: ");
						}
						else
						{
							account.setAccountNo(Long.parseLong(accNo));
							k=1;
						}
					}while(k==0);
					
					System.out.println("Choose Account Type[1,2,3,4]:");
						printAccountType();
						accountTypeNo=scanner.nextInt();
						account.setAccountType(assignAccountType(accountTypeNo));
					
						account.setOpeningDate(LocalDate.now());
						
					System.out.println("Enter Opening Balance:");
					account.setOpeningBalance(scanner.nextDouble());
					
					Account[] account2=customer.getAccount();
					//System.out.println(account);
					for(int i=0;i<account2.length;i++)
					{
						if(account2[i]==null) {
							account2[i]=account;
							break;
						}
					}
					System.out.println(customer);
					
				}else if(choice==2) {
					AccountTransaction tx=new AccountTransaction();
					Transactions transaction;
			
					System.out.println("Choose Any one of the account number:");
					if(customer.getAccount()[0]!=null)
						tx.printAccounts(customer);
					else
						System.out.println("Sorry! No account details present for this Customer.");
					long accountNo=scanner.nextLong();
					
					if(tx.isValidAccount(accountNo, customer)) {
						transaction=new Transactions();
						
						transaction.setTransactionID((int)AccountTransaction.generateTransactionID());
						
						System.out.println("1.Deposit");
						System.out.println("2.Withdrawal");
						System.out.println("Choose your option:");
						int option=scanner.nextInt();
						if(option==1)
							transaction.setTransactionType("credit");
						else if(option==2)
							transaction.setTransactionType("debit");
						else {
							System.out.println("Sorry! invalid option!");
							System.exit(0);
						}
						
						Account account=tx.findAccount(accountNo, customer);
						transaction.setAccount(account);
						transaction.setTransactionDate(LocalDate.now());
						
						System.out.println("Enter amount:");
						transaction.setAmount(scanner.nextDouble());
						transactions[index]=transaction;
						index++;
					}
					
				}
				else if(choice==3) {
					
					printTransactionSummary(transactions);
				}
			else {
					System.out.println("Sorry! Invalid choice. Please try Again!");
				}
			}
			else {
				System.out.println("Invalid Customer Number! Please try Again!");
			}
			
			System.out.println("Would you like to continue[y|n]?");
			myChoice=scanner.next().charAt(0);
		}while(myChoice=='y'||myChoice=='Y');
	System.out.println("\nThank You! Have A Nice Day :)");
	}
	
	public static void printTransactionSummary(Transactions[] transactions) {
		System.out.println("\nTransaction Summary\n--------------------\n");
		
		for(Transactions transaction:transactions) {
			if(transaction!=null) {
			System.out.println(transaction.getTransactionDate() +"\t"
					+ transaction.getTransactionID()+"\t"
					+ transaction.getAccount().getAccountNo()+"\t"
					+transaction.getTransactionType()+"\t"
					+transaction.getAmount()
					);
			}
		}
	}
}