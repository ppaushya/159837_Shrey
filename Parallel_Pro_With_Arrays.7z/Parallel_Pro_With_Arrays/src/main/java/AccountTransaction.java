public class AccountTransaction {
	
	static long accountNo=3314198, transactionID=55476275;

	public Account findAccount(long accountNo,Customer customer) {
		for(Account account:customer.getAccount()) {
			if(account!=null) {
				if(account.getAccountNo()==accountNo) {
					return account;
				}
			}
		}
		
		return null;
	}
	
	public boolean isValidAccount(long accountNo,Customer customer) {
		boolean flag=false;
		
		for(Account account:customer.getAccount()) {
			if(account!=null) {
				if(account.getAccountNo()==accountNo) {
					flag=true;
					break;
				}
			}
		}
		return flag;
	}
	
	public static long generateAccountNo() {
		return accountNo+=17;
	}
	
	public static long generateTransactionID() {
		return transactionID+=17;
	}
	
	public void printAccounts(Customer customer) {
		Account[] accounts=customer.getAccount();
		for(Account account:accounts) {
			if(account!=null)
				System.out.println(account.getAccountNo()+"\t"+account.getAccountType());
			else
				break;
		}
	}
}