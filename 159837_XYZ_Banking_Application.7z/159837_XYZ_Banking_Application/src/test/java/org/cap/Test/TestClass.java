package org.cap.Test;

import static org.junit.Assert.*;

import java.time.LocalDate;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.service.InvalidAmountException;

public class TestClass {
	
	 
		@Mock
		IDemandDraftDAO demandDraftDao;
	 
		static IDemandDraftService demandDraftService;
	 
		@Before
		public void setUpBeforeClass(){
			MockitoAnnotations.initMocks(this);
			demandDraftService = new DemandDraftService(demandDraftDao);
		}
	 
		@Test(expected=IllegalArgumentException.class)
		public void test_addDemandDraftDetails_with_null() throws InvalidAmountException {
			DemandDraft demandDraft = null;
	 
			demandDraftService.add_demanddraft_details(demandDraft);
		}
	 
		@Test(expected=InvalidAmountException.class)
		public void test_addDemandDraftDetails_with_Illegal_Amount() throws InvalidAmountException {
			DemandDraft demandDraft = new DemandDraft(0, "Shrey", "Capgemini", "8866429311", LocalDate.now(), 15, 41, "done success");;
	 
			demandDraftService.add_demanddraft_details(demandDraft);
		}
	 
		@Test
		public void test_addDemandDraftDetails_with_success() throws InvalidAmountException {
			DemandDraft demandDraft = new DemandDraft(1, "Shrey", "Capgemini", "8866429311", LocalDate.now(), 15000, 41, "DD processed");
	 
			Mockito.when(demandDraftDao.add_demanddraft_details(demandDraft)).thenReturn(1);
			demandDraftService.add_demanddraft_details(demandDraft);
	 
			Mockito.verify(demandDraftDao).add_demanddraft_details(demandDraft);
		}
	 
}
