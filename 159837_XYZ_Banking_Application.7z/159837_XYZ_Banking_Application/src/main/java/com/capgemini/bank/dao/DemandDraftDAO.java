package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;

public class DemandDraftDAO implements IDemandDraftDAO {
	
	final static Logger logger=Logger.getLogger(DemandDraftDAO.class);
	
	
	//To create a connection with the SQL
	
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			
			logger.error("Connection Error" , e);
		}
		
		return null;
		
	}

	public int add_demanddraft_details(DemandDraft demand_draft) {
	

		
		int temp = 0;
		
		try(Connection conn=getDbConnection())
		{
			//SQL Query to insert data into the database 
			String sql="insert into demand_draft(customer_Name,in_Favour_Of,phone_number,date_of_transaction,dd_amount,dd_commission,dd_description)"
					  +"values (?,?,?,?,?,?,?)";
		     java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		     pst.setString(1, demand_draft.getCustomer_Name());
		     pst.setString(2, demand_draft.getIn_Favour_Of());
		     pst.setString(3, demand_draft.getPhone_number());
		     
		     Date date = Date.valueOf(demand_draft.getDate_of_transaction());
             pst.setDate(4, date);
             pst.setDouble(5, demand_draft.getDd_amount());
		     pst.setInt(6, demand_draft.getDd_commission());
		     pst.setString(7, demand_draft.getDd_description());

			 int count=pst.executeUpdate();
			
			 if(count>0)
			 {
				 //SQL Query to get the max of TransactionID as it is Auto generated amd will be
				 //maximum for new entry
				 String str="select max(transaction_Id) from demand_draft";
				 
				 java.sql.PreparedStatement pst1=conn.prepareStatement(str);
				 
				 ResultSet set=pst1.executeQuery();
				 
				 while(set.next())
					 temp=set.getInt(1);			 
				 logger.info("Insertion Successful");
			 }
			
		} catch (SQLException e) {
			
			
			logger.error("SQL Insertion Error",e);
			
		}
		
		return temp;
	}

	public DemandDraft getDemandDraftDetails(int Transaction_id) {
		
		DemandDraft dd_object=new DemandDraft();
		try(Connection conn=getDbConnection())
		{
			//SQL Query to Get details from Database
			
		  String sql="select * from demand_draft where Transaction_Id=?";
		  
		  java.sql.PreparedStatement pst=conn.prepareStatement(sql);
		  pst.setInt(1, Transaction_id);
		  
		  ResultSet res=pst.executeQuery();
		  
		  while(res.next())
		  {
			dd_object.setTransaction_Id(Transaction_id);
		    dd_object.setCustomer_Name(res.getString(2));
		    dd_object.setIn_Favour_Of(res.getString(3));
		    dd_object.setPhone_number(res.getString(4));
		    dd_object.setDate_of_transaction(res.getDate(5).toLocalDate());
		    dd_object.setDd_amount(res.getInt(6));
		    dd_object.setDd_commission(res.getInt(7));
		    dd_object.setDd_description(res.getString(8));
		  
		  }
		} catch (SQLException e) {
			
			logger.error("Error in printing",e);
		}
		
		
		return dd_object;
	}
	

}
