package com.capgemini.bank.bean;

import java.time.LocalDate;

public class DemandDraft {


	private int transaction_Id;
	private String customer_Name;
	private String in_Favour_Of;
	private String phone_number;
	private LocalDate date_of_transaction;
	private int dd_amount;
	private int dd_commission;
	private String dd_description;
	
	
	public DemandDraft() {
		super();
	}
	public DemandDraft(int transaction_Id, String customer_Name, String in_Favour_Of, String phone_number,
			LocalDate date_of_transaction, int dd_amount, int dd_commission, String dd_description) {
		super();
		this.transaction_Id = transaction_Id;
		this.customer_Name = customer_Name;
		this.in_Favour_Of = in_Favour_Of;
		this.phone_number = phone_number;
		this.date_of_transaction = date_of_transaction;
		this.dd_amount = dd_amount;
		this.dd_commission = dd_commission;
		this.dd_description = dd_description;
	}
	@Override
	public String toString() {
		return "DemandDraft [transaction_Id=" + transaction_Id + ", customer_Name=" + customer_Name + ", in_Favour_Of="
				+ in_Favour_Of + ", phone_number=" + phone_number + ", date_of_transaction=" + date_of_transaction
				+ ", dd_amount=" + dd_amount + ", dd_commission=" + dd_commission + ", dd_description=" + dd_description
				+ "]";
	}
	public int getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(int transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getCustomer_Name() {
		return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}
	public String getIn_Favour_Of() {
		return in_Favour_Of;
	}
	public void setIn_Favour_Of(String in_Favour_Of) {
		this.in_Favour_Of = in_Favour_Of;
	}
	public String getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}
	public LocalDate getDate_of_transaction() {
		return date_of_transaction;
	}
	public void setDate_of_transaction(LocalDate date_of_transaction) {
		this.date_of_transaction = date_of_transaction;
	}
	public int getDd_amount() {
		return dd_amount;
	}
	public void setDd_amount(int dd_amount) {
		this.dd_amount = dd_amount;
	}
	public int getDd_commission() {
		return dd_commission;
	}
	public void setDd_commission(int dd_commission) {
		this.dd_commission = dd_commission;
	}
	public String getDd_description() {
		return dd_description;
	}
	public void setDd_description(String dd_description) {
		this.dd_description = dd_description;
	}
	
}
