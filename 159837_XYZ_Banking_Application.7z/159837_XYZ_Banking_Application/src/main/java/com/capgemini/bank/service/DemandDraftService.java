package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;

public class DemandDraftService implements IDemandDraftService {
	
	DemandDraftDAO DemandDraftDaoobj=new DemandDraftDAO();


	public DemandDraftService(IDemandDraftDAO demanddraftdao) {
		// TODO Auto-generated constructor stub
	}


	public DemandDraftService() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public int add_demanddraft_details(DemandDraft demand_draft) throws InvalidAmountException {
		
		//Checking if the amount is negative or not
		//If negative it will throw a user-defined Exception called InvalidAmountException
		
		if(demand_draft.getDd_amount()<0)
			throw new InvalidAmountException("Amount Invalid"); 
		
		return DemandDraftDaoobj.add_demanddraft_details(demand_draft);
		
	}
	
	
	//To Check get demand Draft Details if commented block is removed 

	@Override
	public DemandDraft getDemandDraftDetails(int t_id)
	{
		return DemandDraftDaoobj.getDemandDraftDetails(t_id);
	}

	//To check the validation of name
	
	@Override
	public boolean isvalidname(String str) {

		return str.matches("[a-zA-Z]{3,}");	
	}

	//To check the validation of Phone Number
	
	@Override
	public boolean isvalidnumber(String str) {
	
		return str.matches("[7|8|9]{1}\\d{9}");
		
	}

	//To check the validation of Date
	
	@Override
	public boolean isValidDate(String str) {

		return str.matches("[0,1,2,3]\\d{1}/[0,1]\\d{1}/(18|19|20)\\d{2}");
	}

}
