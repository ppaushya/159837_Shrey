package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {

	public boolean isvalidname(String str);
	
	public boolean isvalidnumber(String str);
	
	public boolean isValidDate(String str);
	
	public int add_demanddraft_details(DemandDraft demand_draft) throws InvalidAmountException;
	
	public DemandDraft getDemandDraftDetails(int t_id);
}
