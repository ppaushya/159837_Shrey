package org.capgemini.bank.ui;


import java.time.LocalDate;
import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.InvalidAmountException;


public class Client {
	
	Scanner s=new Scanner(System.in);
	DemandDraftService ddservice=new DemandDraftService();

	//UserInteraction Method to prompt Demand Draft Details
	
	public DemandDraft add_demanddraft_details()
	{
		
		DemandDraft demanddraft=new DemandDraft();
		System.out.println("Enter the Custiomer Name ");
		demanddraft.setCustomer_Name(Cust_name());
		System.out.println("Enter the mobile No");
		demanddraft.setPhone_number(Cust_number());
		System.out.println("In favour of name ");
		String favour;
		favour=s.nextLine();
		demanddraft.setIn_Favour_Of(favour);
		System.out.println("Enter Date Of Transaction [DD/MM/YYYY]:");	
		demanddraft.setDate_of_transaction(dd_date());		
		System.out.println("Enter the amount");
		int amount=s.nextInt();
		demanddraft.setDd_amount(amount);
		System.out.println("Enter the DD Description");
		demanddraft.setDd_description(s.next());
		demanddraft.setDd_commission(cal_commission(amount));
		
		return demanddraft;
	}
	
	//Get Customer Name
	public String Cust_name()
	{
		String name;
		boolean flag=false;
		do {
			name=s.nextLine();
			flag=ddservice.isvalidname(name);
			if(!flag)
				System.out.println("Invalid Name !! Please Enter Again");
		}while(!flag);
		
		return name;
	}
	
	//Get Customer Phone Number

	public String Cust_number()
	{
		String num;
		boolean flag=false;
		do {
			num=s.nextLine();
			flag=ddservice.isvalidnumber(num);
			if(!flag)
				System.out.println("Invalid Number!! Please Enter Again");
		}while(!flag);
		
		return num;
	}
	
	//Calculate Commission according to Amount Entered
	
	public int cal_commission(int amount)
	{
	  if (amount<=5000)
		  return 10;
	  else if(amount>5000 && amount<10000)
		  return 41;
	  else if(amount>10000 && amount<100000)
		  return 51;
	  else if(amount>100000 && amount<500000)
		  return 306;
	return 0;
	}
	
	public LocalDate dd_date() {
		boolean flag=false;
		String date;
		do {			
			date=s.next();
			flag=ddservice.isValidDate(date);
			if(!flag)
				System.out.println("Invalid Date!! Please Enter Again!!");
		}while(!flag);
		String[] dates=date.split("/");
		LocalDate dd_date=LocalDate.of(Integer.parseInt(dates[2]), 
				Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		return dd_date;
	}
	public static void main(String[] args) throws InvalidAmountException
	{
		Scanner s=new Scanner(System.in);
		
		//SQL QUERIES USED TO CREATE TABLE IS AVAILABLE IN THE TEXT FILE
		//WITH NAME "SQL QUERIES" IN THE FOLDER
		
		
		int choice;
		char ch;
		
		Client client=new Client();
		DemandDraft dd_draft=new DemandDraft();
		DemandDraftService DemandDraftService=new DemandDraftService();
		
		
		do
		{

		System.out.println("Enter the choice ");
		System.out.println("1.Enter Demand Draft Details");
		
		//System.out.println("2.Get Demand Draft Details");
		
		System.out.println("2.Exit");
		choice=s.nextInt();
		  switch(choice)
			{
		  
		  //To Enter Demand Draft Details
		  
			case 1 : dd_draft=client.add_demanddraft_details();
			         int Transaction_id=DemandDraftService.add_demanddraft_details(dd_draft);
			         
			         //InvalidAmountException handled here also with throws in Main

			 		System.out.println("----------------------Transaction ID Summary----------------------");
			 		System.out.println("Your Demand Draft request have been successfully registered"
			 	       		 +"along with "+ Transaction_id);
			         
				     break;
				     
			//According to QuestionPaper There is also a getDemandDraftDetails with
		    //Transaction_ID as argument but since it is not shown in sample screen the case has been 
		    //commented..If you want you can also call this by removing the comments
				     
			/*case 2 : System.out.println("Enter The transaction ID");
			         int t_id=s.nextInt();
			         DemandDraft dd_draft1=DemandDraftService.getDemandDraftDetails(t_id);
				     break;*/
				     
				     
			case 2 : System.exit(0);
			     break;
			     
			     
			default : System.out.println("Invalid Option!!");
			
			}
			System.out.println("Want to continue? [Y/N]");
			ch=s.next().charAt(0);
		}while(ch=='y' || ch=='Y');
	}


}
