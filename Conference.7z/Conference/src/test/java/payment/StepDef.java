package payment;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	private WebDriver webdriver;
	private WebElement element;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\shreykpa\\chromedriver.exe");
		webdriver=new ChromeDriver();
	}
	
	@Given("^Open Payment Portal$")
	public void open_Payment_Portal() throws Throwable {

		webdriver.get("file:///C:/Users/shreykpa/Desktop/Conferencebooking/PaymentDetails.html");
	}

	@When("^All the fields are filled$")
	public void all_the_fields_are_filled() throws Throwable {
	   webdriver.findElement(By.name("txtFN")).sendKeys("Shrey");
	   webdriver.findElement(By.name("debit")).sendKeys("9874563210125478");
	   webdriver.findElement(By.name("cvv")).sendKeys("456");
	   webdriver.findElement(By.name("month")).sendKeys("12");
	   webdriver.findElement(By.name("year")).sendKeys("23");
	   Thread.sleep(2000);
	}

	@Then("^Display the message \"(.*?)\"$")
	public void display_the_message(String arg1) throws Throwable {
	    
		webdriver.findElement(By.xpath("//*[@id=\"btnPayment\"]")).click();
		Alert alert=webdriver.switchTo().alert();
		Thread.sleep(2000);
		assertEquals(alert.getText(), "Conference Room Booking successfully done!!!");
		alert.accept();
webdriver.quit();
//		
		/*assertEquals(alert.getText(), "Registration Successful");
		alert.accept();*/
	}


}
