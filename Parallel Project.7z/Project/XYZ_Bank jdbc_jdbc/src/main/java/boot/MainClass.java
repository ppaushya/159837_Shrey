package boot;

import java.sql.ResultSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import model.Account;
import model.Address;
import model.Customer;
import model.Transaction;
import service.CustomerServiceImpl;
import service.ICustomerService;
import view.UserInteraction;
public class MainClass {
	
	static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) {

		ICustomerService customerService=new CustomerServiceImpl();
		UserInteraction userInteraction=new UserInteraction();
		
		Customer customer=new Customer();
		Address address =new Address();
		Account account = new Account();
		Transaction transaction = new Transaction();
		
		System.out.println("\t\t-------------Welcome to Community Bank-------------");
		int  choice;
        String option;
		do {
		System.out.println("1.) Create Customer");
		System.out.println("2.) Create Account");
		System.out.println("3.) Print Customer Details with Account info");
		System.out.println("4.) Do Transaction");
        System.out.println("5.) Transaction Summary");
        System.out.println("6.) Exit");
		System.out.println("Enter Your choice:");
		choice=sc.nextInt();
				
			switch(choice) {
			case 1:
				customer=userInteraction.getCustomerDetails();
				
				userInteraction.createCustomer(customer);
				break;
			case 2:
				customer=userInteraction.chooseCustomer();
				if(customer!=null)
					account=userInteraction.getAccountDetails(customer.getCustomerId());
				
				Account account1=userInteraction.createAccount(account);
				if(account1!=null)
					customer.getAccounts().add(account1);
				break;
			case 3:
				customer=userInteraction.chooseCustomer();
				List<Account> accounts=customerService.getAccountDetails(customer.getCustomerId());
				System.out.println("Account Number | Account Type | OpeningDate | Opening Balance | Description");
				for(Account acc:accounts)
				{
					System.out.println(acc.getAccountNumber()+"\t \t"+acc.getAccountType()+"\t \t"+acc.getOpeningDate()+" \t"+
							acc.getOpeningBalance()+"\t \t"+acc.getDescription());
				}
				break;
			case 4:
				customer=userInteraction.chooseCustomer();
				accounts=customerService.getAccountDetails(customer.getCustomerId());
				System.out.println("Account Number | Account Type | OpeningDate | Opening Balance | Description");
				for(Account acc:accounts)
				{
					System.out.println(acc.getAccountNumber()+" "+acc.getAccountType()+" "+acc.getOpeningDate()+" "+
							acc.getOpeningBalance()+" "+acc.getDescription());
				}
				System.out.println("Choose account No: ");
				int accountNumber=sc.nextInt();
				
				userInteraction.doTransaction(customer.getCustomerId(),accountNumber);
				
				break;
			case 5:
			//transaction Summary
				customer=userInteraction.chooseCustomer();
				List<Transaction> transactions=customerService.getTransactionDetails();
				for(Transaction trans:transactions)
				{
					System.out.println(trans);
					
				}
				break;
			case 6:
				System.exit(0);
			}
			System.out.println("Enter [yes] to continue:");
			option=sc.next();
		}while(option.charAt(0)=='y' || option.charAt(0)=='Y');
	}

}
