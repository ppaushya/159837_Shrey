package org.xyz.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.xyz.model.Account;
import org.xyz.model.AccountType;
import org.xyz.model.Customer;
import org.xyz.model.Transaction;

public class TransactionDbImpl implements ITransactionDao{

	private Connection getConnection() {
		Connection connection = null;
		try {
			File dbPropertiesFile = new File("mysqldb.properties");
			FileInputStream inputStream = new FileInputStream(dbPropertiesFile);
			Properties properties = new Properties();
			properties.load(inputStream);
			
			Class.forName(properties.getProperty("driverClass"));
			connection = DriverManager.getConnection(properties.getProperty("url")
					, properties.getProperty("user"), properties.getProperty("password"));
			return connection;
		} catch (ClassNotFoundException | SQLException | IOException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	@Override
	public Set<Transaction> getAllTransactions() {
		try(Connection connection = getConnection()) {
			String sql = "select t.transactionId, t.transactionDate, t.amount, t.transactionType, t.description, "
					+ "a1.accountNumber, a1.customerId, a1.accountType, a1.openingDate, a1.openingBalance, a1.description,"
					+ "a2.accountNumber, a2.customerId, a2.accountType, a2.openingDate, a2.openingBalance, a2.description"
					+ " from transaction t, account a1 , account a2 "
					+ "where t.fromAccountNumber = a1.accountNumber and t.toAccountNumber = a2.accountNumber";
			PreparedStatement statement = connection.prepareStatement(sql);
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getAllTransactionsOfCustomer(Customer customer) {
		try(Connection connection = getConnection()) {
			String sql = "select t.transactionId, t.transactionDate, t.amount, t.transactionType, t.description, "
					+ "a1.accountNumber, a1.customerId, a1.accountType, a1.openingDate, a1.openingBalance, a1.description,"
					+ "a2.accountNumber, a2.customerId, a2.accountType, a2.openingDate, a2.openingBalance, a2.description"
					+ " from transaction t, account a1 , account a2 "
					+ "where t.fromAccountNumber = a1.accountNumber and t.toAccountNumber = a2.accountNumber"
					+ " and (a1.customerId = ? or a2.customerId=?)";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, customer.getCustomerId());
			statement.setLong(2, customer.getCustomerId());
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Set<Transaction> getAllTransactionsOfAccount(Account account) {
		try(Connection connection = getConnection()) {
			String sql = "select t.transactionId, t.transactionDate, t.amount, t.transactionType, t.description, "
					+ "a1.accountNumber, a1.customerId, a1.accountType, a1.openingDate, a1.openingBalance, a1.description,"
					+ "a2.accountNumber, a2.customerId, a2.accountType, a2.openingDate, a2.openingBalance, a2.description"
					+ " from transaction t, account a1 , account a2 "
					+ "where t.fromAccountNumber = a1.accountNumber and t.toAccountNumber = a2.accountNumber"
					+ " and (fromAccountNumber=? or toAccountNumber=?)";
			PreparedStatement statement = connection.prepareStatement(sql);
			statement.setLong(1, account.getAccountNumber());
			statement.setLong(2, account.getAccountNumber());
			
			ResultSet resultSet = statement.executeQuery();
			return getAllTransactionsFromCursor(resultSet);
			
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		return null;
	}
	
	private Set<Transaction> getAllTransactionsFromCursor(ResultSet resultSet) throws SQLException {
		Set<Transaction> transactions = new HashSet<>();
		
		while(resultSet.next()) {
				Transaction transaction = new Transaction();
				transaction.setTransactionId(resultSet.getLong("t.transactionId"));
				transaction.setTransactionDate(resultSet.getDate("t.transactionDate").toLocalDate());
				
				Account toAccount = new Account();
				toAccount.setAccountNumber(resultSet.getLong("a1.accountNumber"));
				toAccount.setAccountType(AccountType.valueOf(resultSet.getString("a1.accountType")));
				toAccount.setOpeningDate(resultSet.getDate("a1.openingDate").toLocalDate());
				toAccount.setOpeningBalance(resultSet.getDouble("a1.openingBalance"));
				toAccount.setDescription(resultSet.getString("a1.description"));

				Account fromAccount = new Account();
				fromAccount.setAccountNumber(resultSet.getLong("a2.accountNumber"));
				fromAccount.setAccountType(AccountType.valueOf(resultSet.getString("a2.accountType")));
				fromAccount.setOpeningDate(resultSet.getDate("a2.openingDate").toLocalDate());
				fromAccount.setOpeningBalance(resultSet.getDouble("a2.openingBalance"));
				fromAccount.setDescription(resultSet.getString("a2.description"));

				transaction.setFromAccount(fromAccount);
				transaction.setToAccount(toAccount);
				
				transaction.setAmount(resultSet.getDouble("t.amount"));
				transaction.setTransactionType(resultSet.getString("t.transactionType"));
				transaction.setDescription(resultSet.getString("t.description"));
				
				transactions.add(transaction);
			}
		return transactions;
	}

	@Override
	public void createTransaction(Transaction transaction) {
		try(Connection connection = getConnection()) {
			
			String query = "insert into transaction values(null,?,?,?,?,?,?)";
			PreparedStatement statement = connection.prepareStatement(query);
			statement.setDate(1, Date.valueOf(transaction.getTransactionDate()));
			statement.setLong(2, transaction.getFromAccount().getAccountNumber());
			statement.setLong(3, transaction.getToAccount().getAccountNumber());
			statement.setDouble(4, transaction.getAmount());
			statement.setString(5, transaction.getTransactionType());
			statement.setString(6, transaction.getDescription());
			
			if(statement.executeUpdate()>0) {
				System.out.println("Transaction inserted.");
			}else {
				System.out.println("Error occured.");
			} 
		} catch (SQLException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
	}

}
